// База данных десертов
const desserts = [
  {
    id: 1,
    name: "Торт Розовый \"Бантики\"",
    category: "cakes",
    price: 5000,
    pricePerKg: 3000,
    weight: 2400,
    image: "mS9VuIXVCYE.jpg",
    description: {
      biscuit: "Шоколадный",
      cream: "Сливочный крем-чиз",
      filling: "Шоколадный ганаш, Сливочная карамель, Орехи, Вафельная крошка",
      decoration: "Топперы из сахарной бумаги, Фигурки из глазури",
      soaking: "Сахарный сироп"
    }
  },
  {
    id: 2, // Важно: уникальный ID, если будете добавлять вручную
    name: "Торт \"Медовик\"",
    category: "cakes",
    price: 4500,
    pricePerKg: 2500,
    weight: 1800,
    image: "N2WsweSd8D8.jpg", // Укажите правильный путь к файлу
    description: {
      biscuit: "Медовый",
      cream: "Сметанный крем",
      filling: "Медовые коржи",
      decoration: "Медовая крошка",
      soaking: "Медовый сироп"
    }
  },
  {
    id: 3,
    name: "Капкейки \"Ванильные\"",
    category: "cupcakes",
    price: 500,
    pricePerKg: null, // Может быть null или undefined, если не применимо
    weight: null,
    image: "vhlI4hR91AQ.jpg", // Укажите правильный путь к файлу
    description: {
      biscuit: "Ванильный",
      cream: "Крем-чиз",
      filling: "Ягодный конфитюр",
      decoration: "Кремовая шапочка, ягоды",
      soaking: null // Может быть null, если нет пропитки
    }
  }
  // Можно добавить другие десерты...
];

// Массив для хранения заказов
let orders = [];

// Функция для получения десерта по ID
function getDessertById(id) {
  return desserts.find(dessert => dessert.id === id);
}

// Функция для сохранения заказа
function saveOrder(orderData) {
  orders.push(orderData);
  
  // Отправка уведомления на указанный email
  const emailBody = `Новый заказ!\n\nИмя: ${orderData.name}\nТелефон: ${orderData.phone}\nEmail: ${orderData.email}\nДата: ${orderData.date}\nАдрес: ${orderData.location}\nКомментарий: ${orderData.comment}\nДесерт: ${orderData.dessertName}`;
  window.location.href = `mailto:ketrin.alex04@gmail.com?subject=Новый заказ&body=${encodeURIComponent(emailBody)}`;
  
  return true;
}

// Функция для добавления нового десерта (для админки)
function addDessert(dessertData) {
  const newId = Math.max(...desserts.map(d => d.id)) + 1;
  desserts.push({id: newId, ...dessertData});
  return newId;
}

// Экспорт функций и массива desserts
export { getDessertById, saveOrder, addDessert, desserts };